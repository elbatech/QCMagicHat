#!/bin/bash

cd /opt/epz/EPiQ/
python3 EPiQ.py
