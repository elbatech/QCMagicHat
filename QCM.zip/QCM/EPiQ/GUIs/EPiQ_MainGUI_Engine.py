from sys import modules
from os import makedirs
from os.path import splitext, split, join, exists
from subprocess import Popen
from configparser import ConfigParser
from numpy import zeros, array,mean, std, pi, where, sin, cos, arange
from numpy.random import random_sample as rnd
from numpy import min as Min
from numpy import max as Max
from time import sleep, strftime
from datetime import datetime

CURRMOD = list(modules.keys())
try:
    ENV = 'PyQt5'
    CURRMOD.index(ENV)
    from PyQt5.QtWidgets import QFileDialog, QMainWindow, QSpinBox, QRadioButton
    from PyQt5.QtWidgets import QDoubleSpinBox, QMessageBox, QCheckBox, QLineEdit, QInputDialog
    from PyQt5.QtGui import QIcon, QPixmap, QColor, QPalette
    from PyQt5.QtCore import QThread, pyqtSignal, QLocale, Qt
    import pyqtgraph as pg

except:
    ENV = 'PyQt4'
    CURRMOD.index(ENV)
    from PyQt4.QtGui import QFileDialog, QMainWindow,QIcon, QPixmap, QColor, QRadioButton
    from PyQt4.QtGui import QSpinBox, QDoubleSpinBox, QMessageBox, QCheckBox, QLineEdit, QInputDialog, QPalette
    from PyQt4.QtCore import QThread, pyqtSignal, QLocale, Qt
    import pyqtgraph as pg

from GUIs.EPiQ_MainGUI import Ui_EPiQ_MainGUI
from libs import epz
from libs import cursor
from libs import epzInterpreter

pg.setConfigOption('background', 'w')
pg.setConfigOption('foreground', 'k')

VERSION = '1.2.1'
ABOUT = '<p align=\"center\">EPiQ version {0}</p><p align=\"center\">Elbatech</p><br>'.format(VERSION)
aboutFile = open('config/about.txt','r')
for l in aboutFile.readlines():
    ABOUT += '<p align=\"center\">{0}</p>'.format(l)

TEST1 = 1
TEST2 = 3
EPIQCM = 5
EPIQCMQ = 6
CONNTO = 3.0
CONNCNT = 3
CHUNK1S = 1000
# CSCRPATH = '/home/pi/cprogs/si514'
CSCRPATH = '/opt/epz/qcmhat_si514'
FREQ_SHIFT = 80000.0

LOCALE = QLocale(58,country=QLocale.Italy)

def formatAxis6(values,scale,spacing):
    strings = []

    for v in values:
        strings.append('{:.6f}'.format(v))

    return strings


def formatAxis2(values,scale,spacing):
    strings = []

    for v in values:
        strings.append('{:.2f}'.format(v))

    return strings



class EPiQ_main(QMainWindow):

    pens = [{'color':'#0033CC','width':1},{'color':'#FF0000','width':1},{'color':'#009900','width':1},
            {'color':'#9933FF','width':1},{'color':'#996600','width':1},{'color':'#660033','width':1},
            {'color':'#000000','width':1},{'color':'#8D9494','width':1}]
    cPens = [['#009900',False,False],['#9933FF',False,False],['#996600',False,False],['#660033',False,False],
             ['#000000',False,False],['#8D9494',False,False],['#0033CC',False,False],['#FF0000',False,False]]

    def __init__(self,parent=None,verbose=False):

        super(EPiQ_main,self).__init__(parent)

        self.ui = Ui_EPiQ_MainGUI()
        self.ui.setupUi(self)

#        filer = QFileDialog()
#        filer.setWindowFlags(Qt.WindowStaysOnTopHint)
#        if ENV == 'PyQt5':
#            self.cfgFile = str(filer.getOpenFileName(self, 'Select a configuration file', filter='Ini (*.ini)')[0])
#        else:
#            self.cfgFile = str(filer.getOpenFileName(self, 'Select a configuration file', filter='Ini (*.ini)'))
#        if self.cfgFile == '':
#            self.cfgFile = 'config/defaultCfg.ini'
        self.cfgFile = 'config/defaultCfg.ini'

        self.freqCurs = []
        self.qfCurs = []
        self.oldFreqCurs = 0
        self.oldQfCurs = 0
        self.verbose = verbose
        self.connControl = hwReadyThread(self,CONNTO,CONNCNT)
        self.freqAlign = False
        self.qfAlign = False
        self.ui.pointsNumNum.setValue(100)
        self.ui.pointsNumNum.setMinimum(1)
        self.ui.averagesNum.setValue(10)
        self.ui.averagesNum.setMinimum(2)
        self.ui.timeResNumDbl.setMaximum(1000000.00)
        self.ui.timeResNumDbl.setMinimum(100.0/CHUNK1S)
        self.ui.autoSaveIndNum.setValue(1)
        self.ui.autoSaveIndNum.setMinimum(1)
        self.isMass = False
        self.isVisc = False
        self.ui.quartzBasicFreqNumDbl.setValue(0.0)
        qFreqFont = self.ui.quartzBasicFreqLabel.font()
        qFreqFont.setBold(True)
        self.tabBar = self.ui.settingsTabs.tabBar()
        self.ui.quartzBasicFreqLabel.setFont(qFreqFont)
        self.ui.freqPlot.plotItem.vb.menu.removeAction(self.ui.freqPlot.plotItem.vb.menu.actions()[1])
        self.ui.freqPlot.plotItem.vb.menu.removeAction(self.ui.freqPlot.plotItem.vb.menu.actions()[1])
        self.ui.qPlot.plotItem.vb.menu.removeAction(self.ui.qPlot.plotItem.vb.menu.actions()[1])
        self.ui.qPlot.plotItem.vb.menu.removeAction(self.ui.qPlot.plotItem.vb.menu.actions()[1])
        self.ui.freqPlot.plotItem.ctrlMenu.removeAction(self.ui.freqPlot.plotItem.ctrlMenu.actions()[0])
        self.ui.freqPlot.plotItem.ctrlMenu.removeAction(self.ui.freqPlot.plotItem.ctrlMenu.actions()[0])
        self.ui.freqPlot.plotItem.ctrlMenu.removeAction(self.ui.freqPlot.plotItem.ctrlMenu.actions()[0])
        self.ui.freqPlot.plotItem.ctrlMenu.removeAction(self.ui.freqPlot.plotItem.ctrlMenu.actions()[2])
        self.ui.qPlot.plotItem.ctrlMenu.removeAction(self.ui.qPlot.plotItem.ctrlMenu.actions()[0])
        self.ui.qPlot.plotItem.ctrlMenu.removeAction(self.ui.qPlot.plotItem.ctrlMenu.actions()[0])
        self.ui.qPlot.plotItem.ctrlMenu.removeAction(self.ui.qPlot.plotItem.ctrlMenu.actions()[0])
        self.ui.qPlot.plotItem.ctrlMenu.removeAction(self.ui.qPlot.plotItem.ctrlMenu.actions()[2])

        self.ui.freqPlot.plotItem.setRange(xRange=[0, 1000])
        self.ui.autoFrame.setVisible(False)

        self.ui.experimentTab.setParent(None)

        self.oldRadio = None
        self.ui.flowFrame.setEnabled(False)

        self.ui.expBaseNameLine.setText('experiment')
        self.ui.expDirLine.setText('Data')

        self.ui.autoSaveConfCkBox.setEnabled(False)

        '''

        self.allowedParams = ['pointsNumNum','timeResNumDbl','expBaseNameLine','expDirLine',
                              'autoSaveIndNum','autoSaveEnabCkBox','autoSaveConfCkBox',
                              'rawFreqRadio','rawQfRadio','varFreqRadio','varQfRadio']
        '''
        self.allowedParams = []

        self.ui.rawFreqRadio.setChecked(True)
        self.ui.rawQfRadio.setChecked(True)
        self.ui.freqRadio.setChecked(True)

        self.ui.removeFreqCursBtn.setEnabled(False)
        self.ui.removeQfCursBtn.setEnabled(False)
        self.ui.tagCurFreqPosBtn.setEnabled(False)
        self.ui.tagCurQfPosBtn.setEnabled(False)

        self.maxCurs = 2

        self.simpleLogger('Welcome')
        self.applyConfig()
        self.calculateq = self.cfgcalcq

        self.statusDictQ = {'opened': [[self.ui.freqToMassTab, self.ui.measSetTab, self.ui.saveSetTab, ],
                                      [self.ui.playBtn, self.ui.stopBtn, self.ui.freqCursBox, self.ui.qfCursBox]],
                           'initialized': [
                               [self.ui.freqToMassTab, self.ui.measSetTab, self.ui.saveSetTab, self.ui.playBtn,
                                self.ui.qPlotModeFrame, self.ui.qfCursBox],
                               [self.ui.stopBtn, self.ui.freqCursBox, self.ui.qfCursBox]],
                           'running': [[self.ui.stopBtn],
                                       [self.ui.playBtn, self.ui.freqToMassTab, self.ui.measSetTab, self.ui.saveSetTab,
                                        self.ui.freqCursBox, self.ui.qfCursBox]],
                           'quiet': [[self.ui.playBtn, self.ui.freqToMassTab, self.ui.measSetTab, self.ui.saveSetTab,
                                      self.ui.freqCursBox,self.ui.qPlotModeFrame, self.ui.qfCursBox],
                                     [self.ui.removeQfCursBtn, self.ui.removeFreqCursBtn, self.ui.stopBtn]],
                           'still': [
                               [self.ui.freqToMassTab, self.ui.measSetTab, self.ui.saveSetTab, self.ui.freqCursBox,
                                self.ui.qPlotModeFrame, self.ui.qfCursBox],
                               [self.ui.removeQfCursBtn, self.ui.removeFreqCursBtn, self.ui.playBtn, self.ui.stopBtn]],
                           'disconnected': [[],
                                            [self.ui.playBtn, self.ui.stopBtn, self.ui.freqCursBox, self.ui.qfCursBox,
                                             self.ui.freqToMassTab,
                                             self.ui.measSetTab, self.ui.saveSetTab]],
                           'loaded': [[self.ui.freqCursBox, self.ui.qPlotModeFrame, self.ui.qfCursBox],
                                      [self.ui.removeQfCursBtn, self.ui.playBtn, self.ui.stopBtn, self.ui.freqToMassTab,
                                       self.ui.measSetTab, self.ui.saveSetTab, self.ui.removeFreqCursBtn]]}

        self.statusDict = {'opened': [[self.ui.freqToMassTab, self.ui.measSetTab, self.ui.saveSetTab, ],
                                      [self.ui.playBtn, self.ui.stopBtn, self.ui.freqCursBox, self.ui.qfCursBox]],
                           'initialized': [
                               [self.ui.freqToMassTab, self.ui.measSetTab, self.ui.saveSetTab, self.ui.playBtn],
                               [self.ui.stopBtn, self.ui.freqCursBox, self.ui.qfCursBox,self.ui.qPlotModeFrame]],
                           'running': [[self.ui.stopBtn],
                                       [self.ui.playBtn, self.ui.freqToMassTab, self.ui.measSetTab,
                                        self.ui.saveSetTab,
                                        self.ui.freqCursBox, self.ui.qfCursBox]],
                           'quiet': [
                               [self.ui.playBtn, self.ui.freqToMassTab, self.ui.measSetTab, self.ui.saveSetTab,
                                self.ui.freqCursBox],
                               [self.ui.removeQfCursBtn, self.ui.removeFreqCursBtn, self.ui.stopBtn,
                                self.ui.qPlotModeFrame, self.ui.qfCursBox]],
                           'still': [
                               [self.ui.freqToMassTab, self.ui.measSetTab, self.ui.saveSetTab, self.ui.freqCursBox],
                               [self.ui.removeQfCursBtn, self.ui.removeFreqCursBtn, self.ui.playBtn,
                                self.ui.stopBtn,self.ui.qfCursBox,self.ui.qPlotModeFrame]],
                           'disconnected': [[],
                                            [self.ui.playBtn, self.ui.stopBtn, self.ui.freqCursBox,
                                             self.ui.qfCursBox,
                                             self.ui.freqToMassTab,
                                             self.ui.measSetTab, self.ui.saveSetTab]],
                           'loaded': [[self.ui.freqCursBox],
                                      [self.ui.removeQfCursBtn, self.ui.playBtn, self.ui.stopBtn,
                                       self.ui.freqToMassTab, self.ui.qfCursBox,
                                       self.ui.measSetTab, self.ui.saveSetTab, self.ui.removeFreqCursBtn]]}

        self.freqCurve = None
        self.qfCurve = None
        self.freqPlotAxis = self.ui.freqPlot.plotItem.getAxis('left')
        self.freqPlotAxis.tickStrings = formatAxis2
        self.freqPlotAxis.enableAutoSIPrefix(False)
        self.qfPlotAxis = self.ui.qPlot.plotItem.getAxis('left')
        self.qfPlotAxis.enableAutoSIPrefix(False)

        self.ui.freqPlot.plotItem.setLabel('left', 'Frequency [Hz]')

        if self.calculateq == 1:
            self.qfPlotAxis.tickStrings = formatAxis6
            self.ui.qPlot.plotItem.setLabel('left', 'V dissipation [V]')

        self.initExpVar()
        self.dataSaved = False

        self.setStatus('opened')

        self.setLocale()

        if self.simulation:
            self.qcmData = SimulHW(self)
            self.qcmData.start()
            self.setStatus('opened')
        else:
            self.setEpz()
        self.genericConnections()
        self.actionConnections()
        self.booleanConnections()
        self.buttonConnections()

        self.ui.quartzBasicFreqNumDbl.setValue(self.quartzfreq)


    def setStatus(self,status):
        self.status = status
        theDict = self.statusDictQ if self.calculateq == 1 else self.statusDict
        for act in theDict[status][0]:
            act.setEnabled(True)
            for c in act.children():
                try:
                    c.setEnabled(True)
                except:
                    pass
        for dis in theDict[status][1]:
            dis.setEnabled(False)


    def getParamsDict(self,excluded=[],allowed=[]):

        baseDict = {QSpinBox:['NUM','.value()','.setValue(',[]],QDoubleSpinBox:['DBL','.value()','.setValue(',[]],
                    QLineEdit:['LINE','.text()','.setText(',[]],QCheckBox:['CKBOX','.isChecked()','.setChecked(',[]],
                    QRadioButton:['RDBTN','.isChecked()','.setChecked(',[]]}

        parsList = dir(self.ui) if allowed == [] else allowed

        for d in parsList:
            dObj = getattr(self.ui, d)
            try:
                if dObj.isReadOnly() or dObj in excluded:
                    continue
            except:
                pass
            if type(dObj) in baseDict.keys():
                baseDict[type(dObj)][3].append(d)
            else:
                pass

        return baseDict


    def setLocale(self):

        self.localeSet = QLocale(int(self.language),int(self.country))

        lDict = self.getParamsDict()
        for l in lDict[QDoubleSpinBox][3]:
            lObj = eval('self.ui.'+l)
            lObj.setLocale(self.localeSet)


    def applyConfig(self):

        parser = ConfigParser()
        parser.read(self.cfgFile)

        #floatSec = ['QCM','ADC','QUARTZ']
        #intSec = ['DATA']

        for s in parser.sections():
            for o in parser.options(s):
                val = parser.get(s,o)
                try:
                    prop = int(val)
                except:
                    try:
                        prop = float(val)
                    except:
                        if val == 'False':
                            prop = False
                        elif val == 'True':
                            prop = True
                        else:
                            prop = val

                #setattr(self,o,float(parser.get(s,o)) if s in floatSec else (int(parser.get(s,o)) if s in intSec else parser.get(s,o)))
                setattr(self, o, prop)
                if self.verbose:
                    print('Value loaded from section \'{0}\', option \'{1}\': {2} [{3}]'.format(s,o,prop,type(prop)))


    def setEpz(self):
        print('Connecting')
        self.epiqEnv = epz.Environment()
        self.epiqEnv.subport = self.subport
        self.epiqEnv.pubport = self.pubport
        self.epiqEnv.device = self.qcmname
        self.epiqEnv.epserver = self.epserver

        self.qcmData = self.startDataChannel(self.epiqEnv,chunk = self.chunk,
                                                 decimate=self.dec,notifyLength=self.notlen)

        self.qcmComm = epzInterpreter.Commander(self.epiqEnv)
        self.qcmQ = epzInterpreter.QtQuerist(self.epiqEnv)
        self.qcmQ.heardSomething.connect(self.startEpz)
        self.qcmQ.askDevice()
        if not self.connControl.isRunning():
            self.connControl.timeOutSignal.connect(self.epzFailed)
            self.connControl.start()


    def startEpz(self,resp):

        hwCond = int(float(resp)) != EPIQCM and int(float(resp)) != EPIQCMQ
        if self.hwtest:
            hwCond = hwCond and (int(float(resp)) != TEST1 and int(float(resp)) != TEST2)

        if hwCond:
            warning = QMessageBox(self)
            warning.setText('You are trying to use a wrong type of EpsilonPi hardware. Please check if you have '
                            'connected the correct device or, if you are sure about the device, check the '
                            'epz.conf file in the EpsilonPi Raspberry')
            warning.exec_()
            self.close()

        self.qcmData.start()
        self.qcmComm.startDev()
        try: self.qcmQ.heardSomething.disconnect()
        except: pass
        print('Start Epz')
        #self.setStatus('initialized')
        self.normCheck()
        self.ui.action_Reconnect.setEnabled(False)


    def epzFailed(self):

        self.setStatus('disconnected')
        self.ui.action_Reconnect.setEnabled(True)
        self.simpleLogger('Hardware connection failed: Starting \'offline mode\'')


    def reconnect(self):

        self.connControl = hwReadyThread(self,CONNTO,CONNCNT)
        self.setEpz()


    def startDataChannel(self,env,dev=None,tag='DATA',chunk=1000,decimate=10,notifyLength=50):

        channel = epz.QtDATA(env,dev,tag)

        channel.notify = True
        channel.save = False
        channel.chunk = chunk
        channel.decimate = decimate
        channel.notifyLength = notifyLength

        return channel


    def saveParams(self):

        if ENV == 'PyQt5':
            parFileName = str(QFileDialog.getSaveFileName(self,'Choose a name for you parameters file',filter='Parameters Files (*.par)')[0])
        else:
            parFileName = str(QFileDialog.getSaveFileName(self,'Choose a name for you parameters file',filter='Parameters Files (*.par)'))
        if parFileName == '':
            return None
        splitName = splitext(parFileName)
        if splitName[1] != '.par':
            parFileName = splitName[0]+'.par'

        sDict = self.getParamsDict([],self.allowedParams)
        paramsFile = open(parFileName,'w')
        paramsParser = ConfigParser()

        for k in sDict.keys():
            paramsParser.add_section(sDict[k][0])
            for i in range(len(sDict[k][3])):
                paramsParser.set(sDict[k][0], sDict[k][3][i], str(eval('self.ui.'+sDict[k][3][i]+sDict[k][1])))

        paramsParser.write(paramsFile)

        self.simpleLogger('GUI parameters saved in: {0}'.format(parFileName))

        paramsFile.close()


    def loadParams(self):

        if ENV == 'PyQt5':
            parFileName = str(QFileDialog.getOpenFileName(self,'Choose a parameter file:',filter='Par (*.par)')[0])
        else:
            parFileName = str(QFileDialog.getOpenFileName(self,'Choose a parameter file:',filter='Par (*.par)'))
        if parFileName == '':
            return None
        lDict = self.getParamsDict([],self.allowedParams)
        paramsParser = ConfigParser()
        paramsParser.read(parFileName)

        attrList = dir(self.ui)
        for a in attrList:
            for k in lDict.keys():
                if a in lDict[k][3]:
                    value = paramsParser.get(lDict[k][0],a.lower())
                    try:
                        value = str(eval(value))
                    except:
                        value = '\'' + value + '\''
                    eval('self.ui.' + a + lDict[k][2] + value + ')')

        self.simpleLogger('GUI parameters loaded from: {0}'.format(parFileName))


    def initExpVar(self):

        self.freqOffset = 0.0
        self.qfOffset = 0.0
        self.currentPt = 0
        self.currentFreqMax = 100
        self.currentFreqMin = 0
        self.currentQfMax = 1
        self.currentQfMin = 0
        self.acquiredFreq = []
        self.acquiredQf = []
        self.tags = list(zeros(self.ui.pointsNumNum.value()))
        self.ui.freqLcdLabel.setText('Current Mass [kg]' if self.isMass else 'Current Freq [Hz]')
        self.tagLegend = []
        self.dataSaved = False
        self.freqBuf = zeros(self.ui.averagesNum.value())
        self.qfBuf = zeros(self.ui.averagesNum.value())
        self.currentAvgPt = 0

        self.calculateq = self.cfgcalcq


    def stripChartStarter(self):

        self.freqCurve = self.ui.freqPlot.plot([],[],pen=self.pens[0])
        self.tagFreq = self.ui.freqPlot.plot([],[],pen = None,symbol = 'o',symbolPen=self.cPens[self.maxCurs+1][0],symbolBrush=self.cPens[self.maxCurs+1][0])

        if self.calculateq == 1:
            self.qfCurve = self.ui.qPlot.plot([], [], pen=self.pens[1])
            self.tagQf = self.ui.qPlot.plot([], [], pen=None, symbol='o', symbolPen=self.cPens[self.maxCurs + 1][0],
                                            symbolBrush=self.cPens[self.maxCurs + 1][0])
            for i in range(len(self.qfCurs)):
                self.ui.qfCursListCmbBox.setCurrentIndex(0)
                self.removeCursor('qf')



        for i in range(len(self.freqCurs)):
            self.ui.freqCursListCmbBox.setCurrentIndex(0)
            self.removeCursor('freq')

        if 'freqLegend' not in dir(self):
            self.createLegend()

        self.setLegend()


    def createLegend(self):

        self.freqLegend = pg.LegendItem(offset=[100,10])
        self.freqLegend.setParentItem(self.ui.freqPlot.plotItem)
        if self.calculateq == 1:
            self.qfLegend = pg.LegendItem(offset=[100, 10])
            self.qfLegend.setParentItem(self.ui.qPlot.plotItem)


    def setLegend(self,newLabels = []):

        if newLabels == []:
            newLabels = ['Mass','V diss'] if self.isMass else (['Viscosity','V diss'] if self.isVisc else ['Frequency','V diss'])
        if len(self.freqLegend.items)>0:
            for i in range(len(self.freqLegend.items)):
                del self.freqLegend.items[i]
                if self.calculateq == 1:
                    del self.qfLegend.items[i]
        self.freqLegend.addItem(self.freqCurve,'{0} ({1})'.format(newLabels[0],'SAVED' if self.dataSaved else 'NOT SAVED'))
        if self.calculateq == 1:
            self.qfLegend.addItem(self.qfCurve,'{0} ({1})'.format(newLabels[1],'SAVED' if self.dataSaved else 'NOT SAVED'))


    def initPlotAxis(self):

        self.ui.freqPlot.clear()
        if self.calculateq == 1:
            self.ui.qPlot.clear()

        self.stripChartStarter()

        xMax = self.ui.pointsNumNum.value() + 1

        self.ui.freqPlot.plotItem.setRange(xRange=[0,xMax],yRange=[-100,+100])
        if self.calculateq == 1:
            self.ui.qPlot.plotItem.setRange(xRange=[0,xMax],yRange=[-100,+100])


    def axisManager(self):

        xMax = self.ui.pointsNumNum.value() + 1

        self.ui.freqPlot.plotItem.setRange(xRange=[0, xMax])
        if self.ui.autoYFreqBtn.isChecked():
            self.ui.freqPlot.plotItem.setRange(yRange=[self.currentFreqMin,self.currentFreqMax])

        if self.calculateq:
            self.ui.qPlot.plotItem.setRange(xRange=[0, xMax])
            if self.ui.autoYQfBtn.isChecked():
                self.ui.qPlot.plotItem.setRange(yRange=[self.currentQfMin,self.currentQfMax])


    def stripChartManager(self,fy,qfy):
        self.axisManager()
        freqX = self.freqCurve.xData if self.freqCurve.xData is not None else []
        freqY = self.freqCurve.yData if self.freqCurve.yData is not None else []
        x = list(freqX)
        y = list(freqY)
        x.append(self.currentPt)
        y.append(fy)
        self.freqCurve.setData(x,y)
        if self.calculateq == 1:
            qfX = self.qfCurve.xData if self.qfCurve.xData is not None else []
            qfY = self.qfCurve.yData if self.qfCurve.yData is not None else []
            x = list(qfX)
            y = list(qfY)
            x.append(self.currentPt)
            y.append(qfy)
            self.qfCurve.setData(x,y)


    def adaptVoltage(self, a):
        return (a * self.builtinadcrange / self.bitspan)


    def calcFreqValue(self, msb, lsb):
#        return (self.fref + (self.oc1r + self.oc1rs) * self.ftb / (msb * 2**self.adcbitres + lsb))
        return ((self.quartzfreq - FREQ_SHIFT) + (self.oc1r + self.oc1rs) * self.ftb / (msb * 2**self.adcbitres + lsb))


    def resetLabels(self):

        newFont = self.ui.label_11.font()

        self.ui.quartzBasicFreqLabel.setFont(newFont)
        self.ui.quartzDensLabel.setFont(newFont)
        self.ui.quartzViscLabel.setFont(newFont)
        self.ui.toneNumLabel.setFont(newFont)
        self.ui.aParLabel.setFont(newFont)
        self.ui.bParLabel.setFont(newFont)
        self.ui.cParLabel.setFont(newFont)
        self.ui.mediumDensLabel.setFont(newFont)


    def changeSig1(self):

        culprit = self.sender()

        if culprit is self.ui.flowCkBox:
            self.ui.flowFrame.setEnabled(culprit.isChecked())
        elif type(culprit) is QRadioButton:
            if type(self.oldRadio) is QRadioButton:
                if self.oldRadio.parent() is culprit.parent():
                    self.oldRadio = None
                    return
            else:
                self.oldRadio = culprit

        self.isMass = self.ui.massRadio.isChecked()
        self.isVisc = self.ui.viscRadio.isChecked()
        #self.ui.freqToMassTab.setVisible(self.isMass or self.isVisc)
        self.freqAlign = self.isMass or self.isVisc

        self.ui.plot1Label.setText('Mass Plot Mode' if self.isMass else ('Viscosity Plot Mode' if self.isVisc else 'Frequency Plot Mode'))
        self.ui.freqLcdLabel.setText('Current Mass [kg]' if self.isMass else ('Current Visc [kg/(m*s)]' if self.isVisc else 'Current Freq [Hz]'))
        self.ui.freqMeanLabel.setText('Mean Mass [kg]' if self.isMass else ('Mean Visc [kg/(m*s)]' if self.isVisc else 'Mean Freq [Hz]'))
        self.ui.freqVarLabel.setText('Mass Std Dev [kg]' if self.isMass else ('Mean Std Dev [kg/(m*s)]' if self.isVisc else 'Freq Std Dev [Hz]'))

        self.ui.freqPlot.plotItem.setLabel('left','Mass [kg]' if self.isMass else ('Viscosity [kg/(m*s)]' if self.isVisc else 'Frequency [Hz]'))

        if self.isMass or self.isVisc:
            #self.ui.settingsTabs.setCurrentIndex(1)
            self.ui.varFreqRadio.setChecked(True)

            if self.isMass:
                self.gasCheck()
            elif self.isVisc:
                self.liquidCheck()
        else:
            self.normCheck()

        if self.freqCurve:
            self.setLegend()


    def setNewFreq(self,v):

        strV = "{:10.4f}".format(v)

        parser = ConfigParser()
        parser.read(self.cfgFile)
        parser.set('QCM','fquartzbase',strV)
        parser.set('QUARTZ','quartzfreq',strV)
        self.quartzfreq = v
        fp = open(self.cfgFile,'w')
        parser.write(fp)
        fp.close()

        if self.remote == 1:
            self.qcmComm.startScript() # Il comando usato è 'START_SI514' che va aggiunto allo zmqcommands.conf sul raspberry
        else:
            Popen(['sudo',CSCRPATH])


    def liquidCheck(self):

        print('Checking Liquid')

        if not self.isVisc:
            return

        densCheck = self.ui.mediumDensNumDbl.value() > 0.0
        aCheck = self.ui.aParNumDbl.value() != 0.0
        bCheck = self.ui.bParNumDbl.value() != 0.0
        #cCheck = self.ui.cParNumDbl.value() != 0.0
        qFreqCheck = self.ui.quartzBasicFreqNumDbl.value() > 0.0
        qViscCheck = self.ui.quartzViscNumDbl.value() > 0.0
        qDensCheck = self.ui.quartzDensNumDbl.value() > 0.0

        self.resetLabels()

        doneFont = self.ui.mediumDensLabel.font()
        todoFont = self.ui.mediumDensLabel.font()

        doneFont.setBold(False)
        todoFont.setBold(True)

        if self.verbose:
            print('densCheck: {0}'.format(densCheck))
            print('aCheck: {0}'.format(aCheck))
            print('bCheck: {0}'.format(bCheck))
            print('qFreqCheck: {0}'.format(qFreqCheck))
            print('qViscCheck: {0}'.format(qViscCheck))
            print('qDensCheck: {0}'.format(qDensCheck))

        flowToCheck = array([densCheck,aCheck,bCheck,qFreqCheck])
        toCheck = array([densCheck,qDensCheck,qFreqCheck,qViscCheck])

        self.ui.quartzBasicFreqLabel.setFont(doneFont if qFreqCheck else todoFont)
        self.ui.mediumDensLabel.setFont(doneFont if densCheck else todoFont)

        if self.ui.flowCkBox.isChecked():
            self.ui.aParLabel.setFont(doneFont if aCheck else todoFont)
            self.ui.bParLabel.setFont(doneFont if bCheck else todoFont)
            self.ui.flowFrame.setEnabled(True)
            if flowToCheck.all():
                if self.freqCurve:
                    self.setStatus('quiet')
                else:
                    self.setStatus('initialized')
            else:
                if self.freqCurve:
                    self.setStatus('still')
                else:
                    self.setStatus('opened')
        else:
            self.ui.flowFrame.setEnabled(False)
            self.ui.quartzDensLabel.setFont(doneFont if qDensCheck else todoFont)
            self.ui.quartzViscLabel.setFont(doneFont if qViscCheck else todoFont)
            if toCheck.all():
                if self.freqCurve:
                    self.setStatus('quiet')
                else:
                    self.setStatus('initialized')
            else:
                if self.freqCurve:
                    self.setStatus('still')
                else:
                    self.setStatus('opened')
        self.ui.freqPlotModeFrame.setEnabled(not self.isMass and not self.isVisc)


    def gasCheck(self):

        print('Checking Gas')

        if not self.isMass:
            return

        qFreqCheck = self.ui.quartzBasicFreqNumDbl.value() > 0.0
        qViscCheck = self.ui.quartzViscNumDbl.value() > 0.0
        qDensCheck = self.ui.quartzDensNumDbl.value() > 0.0
        tNumCheck = self.ui.overToneNumDbl.value() > 0.0

        self.resetLabels()

        doneFont = self.ui.quartzDensLabel.font()
        todoFont = self.ui.quartzDensLabel.font()

        doneFont.setBold(False)
        todoFont.setBold(True)

        self.ui.toneNumLabel.setFont(doneFont if tNumCheck else todoFont)
        self.ui.quartzBasicFreqLabel.setFont(doneFont if qFreqCheck else todoFont)
        self.ui.quartzDensLabel.setFont(doneFont if qDensCheck else todoFont)
        self.ui.quartzViscLabel.setFont(doneFont if qViscCheck else todoFont)

        toCheck = array([qDensCheck,qFreqCheck,qViscCheck,tNumCheck])

        if toCheck.all():
            if self.freqCurve:
                self.setStatus('quiet')
            else:
                self.setStatus('initialized')
        else:
            if self.freqCurve:
                self.setStatus('still')
            else:
                self.setStatus('opened')

        self.ui.freqPlotModeFrame.setEnabled(not self.isMass and not self.isVisc)


    def normCheck(self):

        print('Checking Normal')

        if self.isMass or self.isVisc:
            return

        qFreqCheck = self.ui.quartzBasicFreqNumDbl.value() > 0.0

        doneFont = self.ui.quartzDensLabel.font()
        todoFont = self.ui.quartzDensLabel.font()

        doneFont.setBold(False)
        todoFont.setBold(True)

        self.resetLabels()

        self.ui.quartzBasicFreqLabel.setFont(doneFont if qFreqCheck else todoFont)

        if qFreqCheck:
            if self.freqCurve:
                self.setStatus('quiet')
            else:
                self.setStatus('initialized')
        else:
            if self.freqCurve:
                self.setStatus('still')
            else:
                self.setStatus('opened')

        self.ui.freqPlotModeFrame.setEnabled(not self.isMass and not self.isVisc)


    def rawOrAligned(self):

        culprit = self.sender()

        if type(culprit) is QRadioButton:
            if type(self.oldRadio) is QRadioButton:
                if self.oldRadio.parent() is culprit.parent():
                    self.oldRadio = None
                    return
            else:
                self.oldRadio = culprit

        if culprit is self.ui.rawFreqRadio or culprit is self.ui.varFreqRadio:
            self.freqAlign = self.ui.varFreqRadio.isChecked()
        if self.calculateq == 1:
            if culprit is self.ui.rawQfRadio or culprit is self.ui.varQfRadio:
                self.qfAlign = self.ui.varQfRadio.isChecked()

        if self.verbose:
            printLabel = 'Frequency' if culprit is self.ui.rawFreqRadio or culprit is self.ui.varFreqRadio else 'V diss'
            attrLabel = ' variation with respect to the first acquired valued' if self.freqAlign or self.qfAlign else 'n absolute value'
            print('You will see the {0} as a{1}'.format(printLabel,attrLabel))


    def changeChunkLen(self,v):

        self.qcmData.chunk = int(v*CHUNK1S)


    def freqPlotSignalCalc(self,value):

        if self.freqAlign:
            value-=self.freqOffset
        if self.isMass:
            freqToMass = (-2*self.ui.overToneNumDbl.value()*self.ui.quartzBasicFreqNumDbl.value()**2)/(self.ui.quartzViscNumDbl.value()*self.ui.quartzDensNumDbl.value())
            value = value/freqToMass
        if self.isVisc:
            if self.ui.flowCkBox.isChecked():
                value = ((self.ui.quartzBasicFreqNumDbl.value()+self.ui.cParNumDbl.value()-self.ui.aParNumDbl.value()*(self.ui.mediumDensNumDbl.value()**(1/2))/self.ui.bParNumDbl.value()))**2
            else:
                value = ((pi*self.ui.quartzDensNumDbl.value()*self.ui.quartzViscNumDbl.value())/(self.ui.mediumDensNumDbl.value()*(self.ui.quartzBasicFreqNumDbl.value()**3)))*(value**2)

        return value


    def manageChunk(self,v):

        msbArray = array(v[1])
        lsbArray = array(v[2])
        freqArray = self.calcFreqValue(msbArray,lsbArray)

        self.currentPt += 1
        pctg = int((self.currentPt/float(self.ui.pointsNumNum.value()))*100)
        self.ui.experimentProg.setValue(pctg)
        currentFreq = mean(freqArray)
        if self.calculateq == 1:
            qfArray = array(v[0])
            qfArray = self.adaptVoltage(qfArray)
            currentQf = mean(qfArray)
        if self.currentPt == 1:
            #self.freqOffset = currentFreq if self.freqAlign else 0
            self.freqOffset = self.ui.quartzBasicFreqNumDbl.value()
            if self.calculateq == 1:
                self.qfOffset = currentQf if self.qfAlign else 0
        currentFreq = self.freqPlotSignalCalc(currentFreq)
        if self.currentPt == 2:
            self.currentFreqMin = min(self.acquiredFreq[0],currentFreq)
            self.currentFreqMax = max(self.acquiredFreq[0],currentFreq)
            if self.calculateq == 1:
                self.currentQfMin = min(self.acquiredQf[0], currentQf)
                self.currentQfMax = max(self.acquiredQf[0],currentQf)
        if self.calculateq == 1:
            currentQf -= self.qfOffset
            self.ui.currQfValLine.setText('{:.6f}'.format(currentQf))

        self.ui.currFreqValLine.setText('{:.2f}'.format(currentFreq))

        if self.currentPt%(self.ui.averagesNum.value()+1) == 0:
            mf = mean(self.freqBuf)
            sf = std(self.freqBuf)
            self.ui.meanFreqValLine.setText('{:.2f}'.format(mf))
            self.ui.stdDevFreqValLine.setText('{:.2f}'.format(sf))
            if self.calculateq == 1:
                mqf = mean(self.qfBuf)
                sqf = std(self.qfBuf)
                self.ui.meanQfValLine.setText('{:.6e}'.format(mqf))
                self.ui.stdDevQfValLine.setText('{:.6e}'.format(sqf))
        else:
            self.freqBuf[self.currentPt%(self.ui.averagesNum.value()+1)-1] = currentFreq
            if self.calculateq == 1:
                self.qfBuf[self.currentPt%(self.ui.averagesNum.value()+1)-1] = currentQf

        self.acquiredFreq.append(currentFreq)
        if currentFreq > self.currentFreqMax:
            self.currentFreqMax = currentFreq
        elif currentFreq < self.currentFreqMin:
            self.currentFreqMin = currentFreq
        if self.calculateq == 1:
            self.acquiredQf.append(currentQf)
            if currentQf > self.currentQfMax:
                self.currentQfMax = currentQf
            elif currentQf < self.currentQfMin:
                self.currentQfMin = currentQf
        if self.calculateq == 1:
            self.stripChartManager(currentFreq,currentQf)
        else:
            self.stripChartManager(currentFreq, [])
        if self.currentPt == self.ui.pointsNumNum.value():
            self.stopExperiment()
            if self.ui.autoSaveEnabCkBox.isChecked() and self.ui.expBaseNameLine.text() != '':
                if self.ui.autoSaveConfCkBox.isChecked():
                    reply = self.simpleQuestion('Do you want to save the current experiment?')
                    if reply == QMessageBox.Yes:
                        path = join(self.ui.expDirLine.text(),self.ui.expBaseNameLine.text()+'_{0}.qcm'.format(self.ui.autoSaveIndNum.value()))
                        self.ui.autoSaveIndNum.setValue(self.ui.autoSaveIndNum.value()+1)
                        self.saveData(path)
                else:
                    path = join(self.ui.expDirLine.text(),self.ui.expBaseNameLine.text()+'_{0}.qcm'.format(self.ui.autoSaveIndNum.value()))
                    self.ui.autoSaveIndNum.setValue(self.ui.autoSaveIndNum.value()+1)
                    self.saveData(path)
        else:
            self.ui.msgLine.setText('Point {0} of {1}'.format(self.currentPt+1,self.ui.pointsNumNum.value()))


    def startExperiment(self):

        if not self.dataSaved and self.acquiredFreq != []:
            reply = QMessageBox.question(self, 'Message',
                                         "You have unsaved data. By starting a new experiment you will lose them. Do you want to continue?",
                                         QMessageBox.Yes, QMessageBox.No)
            if reply == QMessageBox.No:
                return

        self.ui.autoFrame.setVisible(True)
        self.ui.experimentProg.setValue(0)
        self.ui.msgLine.setText('Point {0} of {1}'.format(self.currentPt+1,self.ui.pointsNumNum.value()))

        self.initExpVar()
        self.initPlotAxis()

        self.freqLegend.setVisible(False)
        if self.calculateq == 1:
            self.qfLegend.setVisible(False)

        self.qcmData.chunkReceived.connect(self.manageChunk)
        self.tabBar.setVisible(False)
        self.ui.settingsTabs.addTab(self.ui.experimentTab,'Experiment')
        self.ui.settingsTabs.setCurrentIndex(3)
        self.setStatus('running')


    def stopExperiment(self):

        try:
            self.qcmData.chunkReceived.disconnect()
        except:
            pass
        self.ui.autoFrame.setVisible(False)
        self.tags = zeros(len(self.acquiredFreq))
        self.freqLegend.setVisible(True)
        if self.calculateq == 1:
            self.qfLegend.setVisible(True)
        self.setLegend()
        self.ui.settingsTabs.setCurrentIndex(0)
        self.ui.experimentTab.setParent(None)
        self.tabBar.setVisible(True)
        self.setStatus('quiet')


    def preCheckAutoSaveEnv(self):

        if self.ui.autoSaveEnabCkBox.isChecked():
            self.checkAutoSaveEnv(True)


    def checkAutoSaveEnv(self,v):

        if not v:
            return
        currentPath = join(self.ui.expDirLine.text(),self.ui.expBaseNameLine.text()+'_{0}.qcm'.format(self.ui.autoSaveIndNum.value()))

        try:
            self.ui.autoSaveIndNum.valueChanged.disconnect()
            self.ui.expBaseNameLine.textChanged.disconnect()
            self.ui.expDirLine.textChanged.disconnect()
        except Exception as e:
            print(e)

        while exists(currentPath):
            reply1 = self.simpleQuestion('The path you have set already exists, Do you want to increment the index until an available path is found?')
            if reply1 == QMessageBox.Yes:
                while exists(currentPath):
                    self.ui.autoSaveIndNum.setValue(self.ui.autoSaveIndNum.value()+1)
                    currentPath = join(self.ui.expDirLine.text(),self.ui.expBaseNameLine.text()+'_{0}.qcm'.format(self.ui.autoSaveIndNum.value()))
                break
            reply2 = self.simpleQuestion('Do tou want to change the directory?')
            if reply2 == QMessageBox.Yes:
                self.browseDataDir()
                currentPath = join(self.ui.expDirLine.text(),self.ui.expBaseNameLine.text()+'_{0}.qcm'.format(self.ui.autoSaveIndNum.value()))
                continue
            reply3 = self.simpleQuestion('Do you want to change the file \'basename\'?')
            if reply3 == QMessageBox.Yes:
                basename,ok = QInputDialog.getText(self,'Base curve name','Enter a base name for you curves:',QLineEdit.Normal)
                if basename and ok:
                    self.ui.expBaseNameLine.setText(basename)
                    currentPath = join(self.ui.expDirLine.text(),self.ui.expBaseNameLine.text()+'_{0}.qcm'.format(self.ui.autoSaveIndNum.value()))
            else:
                break
        self.ui.expBaseNameLine.textChanged.connect(self.preCheckAutoSaveEnv)
        self.ui.expDirLine.textChanged.connect(self.preCheckAutoSaveEnv)
        self.ui.autoSaveIndNum.valueChanged.connect(self.preCheckAutoSaveEnv)


    def browseDataDir(self):

        dir = QFileDialog.getExistingDirectory(self, 'Select a directory...\n')
        if dir == '' or dir == None:
            dir = 'Data'
        self.ui.expDirLine.setText(dir)


    def saveData(self, path = None):

        if path == None:
            if ENV == 'PyQt5':
                dataFileName = str(QFileDialog.getSaveFileName(self,'Choose a name for you data file',filter='Parameters Files (*.qcm)')[0])
            else:
                dataFileName = str(QFileDialog.getSaveFileName(self,'Choose a name for you data file',filter='Parameters Files (*.qcm)'))
            if dataFileName == '':
                return None
            splitName = splitext(dataFileName)
            if splitName[1] != '.qcm':
                dataFileName = splitName[0]+'.qcm'
            path = dataFileName

        fold = split(path)[0]
        if not exists(fold):
            makedirs(fold)
        whatToSave = self.prepareHeader() + self.prepareSaveString()

        dataFile = open(path,'w')
        dataFile.write(whatToSave)
        self.dataSaved = True
        self.setLegend()


    def prepareSaveString(self):

        ramp = list(array(list(range(self.ui.pointsNumNum.value()))).astype(str))
        freq = list(array(self.acquiredFreq).astype(str))
        tags = list(array(self.tags).astype(str))
        if self.calculateq == 1:
            qf = list(array(self.acquiredQf).astype(str))
            stringListList = list(zip(ramp,freq,qf,tags))
        else:
            stringListList = list(zip(ramp, freq, tags))
        stringList = ['\t'.join(ll)+'\n' for ll in stringListList]
        dataString = ''
        for l in stringList:
            dataString += l

        return dataString


    def prepareHeader(self):

        headerStr = ''
        headerStr += '# Number of points:\t{0}\n'.format(self.ui.pointsNumNum.value())
        headerStr += '# Time Res:\t{0}\n'.format(self.ui.timeResNumDbl.value())
        headerStr += '# Dissipation measured:\t{0}'.format('yes' if self.calculateq==1 else 'no')
        if self.freqOffset != 0.0:
            headerStr += '# Freq offset[Hz]:\t{0}\n'.format(self.freqOffset)
        if self.qfOffset != 0:
            headerStr += '# V dissipation offset:\t{0}\n'.format(self.qfOffset)
        if self.isMass:
            headerStr += '# Mass Measurement\n'
            headerStr += '# Quartz basic frequency [Hz]:\t{0}\n'.format(self.ui.quartzBasicFreqNumDbl.value())
            headerStr += '# Quartz density [g/cm3]:\t{0}\n'.format(self.ui.quartzDensNumDbl.value())
            headerStr += '# Quartz viscosity [kg/(m*s)]:\t{0}\n'.format(self.ui.quartzViscNumDbl.value())
            headerStr += '# Quartz overtone number:\t{0}\n'.format(self.ui.overToneNumDbl.value())
        elif self.isVisc:
            headerStr += '# Viscosity Measurement - {0}\n'.format('Flow' if self.ui.flowCkBox.isChecked() else 'No Flow')
            headerStr += '# Quartz basic frequency [Hz]:\t{0}\n'.format(self.ui.quartzBasicFreqNumDbl.value())
            headerStr += '# Medium density [g/cm3]:\t{0}\n'.format(self.ui.mediumDensNumDbl.value())
            if self.ui.flowCkBox.isChecked():
                headerStr += '# a parameter:\t{0}\n'.format(self.ui.aParNumDbl.value())
                headerStr += '# b parameter:\t{0}\n'.format(self.ui.bParNumDbl.value())
                headerStr += '# c parameter:\t{0}\n'.format(self.ui.cParNumDbl.value())
            else:
                headerStr += '# Quartz density [g/cm3]:\t{0}\n'.format(self.ui.quartzDensNumDbl.value())
                headerStr += '# Quartz viscosity [kg/(m*s)]:\t{0}\n'.format(self.ui.quartzViscNumDbl.value())

        for t in self.tagLegend:
            headerStr += '# Tag number {0}:\t{1}\n'.format(self.tagLegend.index(t)+1,t)
        freqHeaderLabel = 'Mass[g]' if self.isMass else ('Viscosity [kg/(m*s)]' if self.isVisc else 'Frequency[Hz]')
        if self.calculateq == 1:
            headerStr += '#Point number\t{0}\tV dissipation [V]\tTags\n'.format(freqHeaderLabel)
        else:
            headerStr += '#Point number\t{0}\tTags\n'.format(freqHeaderLabel)

        return headerStr


    def loadData(self):

        if ENV == 'PyQt5':
            dataFileName = str(QFileDialog.getOpenFileName(self,'Choose a data file',filter='Parameters Files (*.qcm)')[0])
        else:
            dataFileName = str(QFileDialog.getOpenFileName(self,'Choose a data file',filter='Parameters Files (*.qcm)'))
        if dataFileName == '':
            return None

        self.sigChangerDisconnect()
        self.sigCheckerDisconnect()

        dataFile = open(dataFileName,'r')
        data = []

        dataStarted = False
        newFile = False

        tempTagsText = []

        for l in dataFile.readlines():
            if l[0] != '#' and l[0] != '\n' and not dataStarted:
                dataStarted = True
            elif l[0] == '#' and l.find('Number') != -1:
                val = float(l.split('\t')[1])
                self.ui.pointsNumNum.setValue(val)
            elif l[0] == '#' and l.find('Mass Meas') != -1:
                self.isMass == True
            elif l[0] == '#' and l.find('Viscosity Meas') != -1:
                self.isVisc == True
            elif l[0] == '#' and l.find('Quartz d') != -1:
                val = float(l.split('\t')[1])
                self.ui.quartzDensNumDbl.setValue(val)
            elif l[0] == '#' and l.find('Quartz v') != -1:
                val = float(l.split('\t')[1])
                self.ui.quartzViscNumDbl.setValue(val)
            elif l[0] == '#' and l.find('Quartz b') != -1:
                val = float(l.split('\t')[1])
                self.ui.quartzBasicFreqNumDbl.setValue(val)
            elif l[0] == '#' and l.find('Quartz d') != -1:
                val = float(l.split('\t')[1])
                self.ui.quartzDensNumDbl.setValue(val)
            elif l[0] == '#' and l.find('Quartz o') != -1:
                val = float(l.split('\t')[1])
                self.ui.overToneNumDbl.setValue(val)
            elif l[0] == '#' and l.find('Medium d') != -1:
                val = float(l.split('\t')[1])
                self.ui.mediumDensNumDbl.setValue(val)
            elif l[0] == '#' and l.find('a param') != -1:
                val = float(l.split('\t')[1])
                self.ui.aParNumDbl.setValue(val)
            elif l[0] == '#' and l.find('b param') != -1:
                val = float(l.split('\t')[1])
                self.ui.bParNumDbl.setValue(val)
            elif l[0] == '#' and l.find('c param') != -1:
                val = float(l.split('\t')[1])
                self.ui.cParNumDbl.setValue(val)
            elif l[0] == '#' and l.find('Time') != -1:
                val = float(l.split('\t')[1])
                self.ui.timeResNumDbl.setValue(val)
            elif l[0] == '#' and l.find('Dissipation measured') != -1:
                val = l.split('\t')[1]
                newFile = True
                self.calculateq = 1 if val=='yes' else 0
            elif l[0] == '#' and l.find('Tag') != -1:
                tempTagsText.append(l.split('\t')[1][:-1])
            if dataStarted:
                data.append([float(d) for d in l.split('\t')])

        if not newFile:
            self.calculateq = 1
        if self.qcmData.isRunning():
            self.setStatus('quiet')
        else:
            self.setStatus('loaded')
        self.initPlotAxis()
        data = array(data)
        self.currentFreqMax = Max(data[:,1])
        self.currentFreqMin = Min(data[:,1])
        self.acquiredFreq = data[:, 1]
        if self.calculateq == 1:
            self.currentQfMax = Max(data[:,2])
            self.currentQfMin = Min(data[:,2])
            self.acquiredQf = data[:,2]
            self.tags = list(zeros(data.shape[0]))
            tempTagsPos = where(array(data[:,3])>0)[0] + 1
        else:
            self.tags = list(zeros(data.shape[0]))
            tempTagsPos = where(array(data[:, 2]) > 0)[0] + 1

        if self.verbose:
            print('Data length: {0}'.format(data.shape[0]))
            print('Frequency Max: {0}'.format(Max(data[:,1])))
            print('Frequency Min: {0}'.format(Min(data[:,1])))
            print('V dissipation Max: {0}'.format(Max(data[:,2])))
            print('V dissipation Min: {0}'.format(Min(data[:,2])))

        self.axisManager()
        self.freqCurve = self.ui.freqPlot.plot(data[:,0],data[:,1],pen=self.pens[0])
        if self.calculateq == 1:
            self.qfCurve = self.ui.qPlot.plot(data[:,0],data[:,2],pen=self.pens[1])

        i = 0
        for t in tempTagsPos:
            self.applyTag(t,tempTagsText[int(data[int(t)-1,3])-1])
            i+=1

        self.dataSaved = True
        self.setLegend()

        self.sigChangerConnections()
        self.sigCheckerConnections()

        logString = 'Loaded data from file: \'{0}\''.format(dataFileName)
        self.simpleLogger(logString)


    def addCursor(self):

        culprit = self.sender()
        friend = self.ui.removeFreqCursBtn if culprit is self.ui.addFreqCurBtn else self.ui.removeQfCursBtn
        tagger = self.ui.tagCurFreqPosBtn if culprit is self.ui.addFreqCurBtn else self.ui.tagCurQfPosBtn
        placeHolder = 1 if culprit is self.ui.addFreqCurBtn else 2
        if not friend.isEnabled():
            tagger.setEnabled(True)
            friend.setEnabled(True)
        curve = self.freqCurve if culprit is self.ui.addFreqCurBtn else self.qfCurve
        cursList = self.freqCurs if culprit is self.ui.addFreqCurBtn else self.qfCurs
        cursorCmb = self.ui.freqCursListCmbBox if culprit is self.ui.addFreqCurBtn else self.ui.qfCursListCmbBox
        parentPlot = self.ui.freqPlot.plotItem if culprit is self.ui.addFreqCurBtn else self.ui.qPlot.plotItem
        disconnector = self.disconnectFreqCursor if culprit is self.ui.addFreqCurBtn else self.disconnectQfCursor

        for c in self.cPens:
            currPen = c
            if not c[placeHolder]:
                c[placeHolder] = True
                break

        newCurs = cursor.Cursor(parentPlot,0,True,True,'o',currPen[0],curve)
        disconnector()
        cursList.append(newCurs)
        cursorCmb.addItem('Cursor: {0}'.format(len(cursList)))
        cursorCmb.setCurrentIndex(len(cursList)-1)
        if cursorCmb.count() == self.maxCurs:
            culprit.setEnabled(False)


    def removeCursor(self,faker = ''):
        culprit = self.sender()
        if culprit is self.ui.removeFreqCursBtn or faker == 'freq':
            if self.ui.freqCursListCmbBox.count() == 1:
                self.ui.freqCursListCmbBox.currentIndexChanged.disconnect()
            if not self.ui.addFreqCurBtn.isEnabled():
                self.ui.addFreqCurBtn.setEnabled(True)
            ind = self.ui.freqCursListCmbBox.currentIndex()
            self.freqCurs[ind].suicide()
            self.ui.freqPlot.update()
            del self.freqCurs[ind]
            self.cPens[ind][1] = False
            if ind < self.ui.freqCursListCmbBox.count()-1:
                for i in range(self.ui.freqCursListCmbBox.count()-1-ind):
                    self.ui.freqCursListCmbBox.setItemText(i+ind+1,'Cursor: {0}'.format(ind+1))
            self.ui.freqCursListCmbBox.removeItem(ind)
            if self.ui.freqCursListCmbBox.count() == 0:
                self.ui.freqCursXNum.setValue(0)
                self.ui.freqCursYNumDbl.setValue(0.0)
                self.ui.freqCursListCmbBox.currentIndexChanged.connect(self.connectFreqCursor)
                self.ui.removeFreqCursBtn.setEnabled(False)
                self.ui.tagCurFreqPosBtn.setEnabled(False)
        elif culprit is self.ui.removeQfCursBtn or faker == 'qf':
            if self.ui.qfCursListCmbBox.count() == 1:
                self.ui.qfCursListCmbBox.currentIndexChanged.disconnect()
            if not self.ui.addQfCurBtn.isEnabled():
                self.ui.addQfCurBtn.setEnabled(True)
            ind = self.ui.qfCursListCmbBox.currentIndex()
            self.qfCurs[ind].suicide()
            self.ui.qPlot.update()
            del self.qfCurs[ind]
            self.cPens[ind][2] = False
            if ind < self.ui.qfCursListCmbBox.count()-1:
                for i in range(self.ui.qfCursListCmbBox.count()-1-ind):
                    self.ui.qfCursListCmbBox.setItemText(i+ind+1,'Cursor: {0}'.format(ind+1))
            self.ui.qfCursListCmbBox.removeItem(ind)
            if self.ui.qfCursListCmbBox.count() == 0:
                self.ui.qfCursXNum.setValue(0)
                self.ui.qfCursYNumDbl.setValue(0.0)
                self.ui.qfCursListCmbBox.currentIndexChanged.connect(self.connectQfCursor)
                self.ui.removeQfCursBtn.setEnabled(False)
                self.ui.tagCurQfPosBtn.setEnabled(False)


    def trackCursor(self,v):

        culprit = self.sender()
        if culprit in self.freqCurs:
            ind = self.freqCurs.index(culprit)
            try: self.ui.freqCursListCmbBox.currentIndexChanged.disconnect()
            except: pass
            self.ui.freqCursListCmbBox.setCurrentIndex(ind)
            self.ui.freqCursListCmbBox.currentIndexChanged.connect(self.connectFreqCursor)
            self.ui.freqCursXNum.setValue(v[0])
            self.ui.freqCursYNumDbl.setValue(v[1])
            if v[0] in self.tagFreq.xData:
                tInd = list(self.tagFreq.xData).index(v[0])
                self.ui.freqTagLine.setText(self.tagLegend[tInd])
                self.ui.tagCurFreqPosBtn.setText('Remove Tag')
            else:
                self.ui.freqTagLine.setText('')
                self.ui.tagCurFreqPosBtn.setText('Tag It')
        else:
            ind = self.qfCurs.index(culprit)
            try: self.ui.qfCursListCmbBox.currentIndexChanged.disconnect()
            except: pass
            self.ui.qfCursListCmbBox.setCurrentIndex(ind)
            self.ui.qfCursListCmbBox.currentIndexChanged.connect(self.connectQfCursor)
            self.ui.qfCursXNum.setValue(v[0])
            self.ui.qfCursYNumDbl.setValue(v[1])
            if v[0] in self.tagQf.xData:
                tInd = list(self.tagQf.xData).index(v[0])
                self.ui.qfTagLine.setText(self.tagLegend[tInd])
                self.ui.tagCurQfPosBtn.setText('Remove Tag')
            else:
                self.ui.qfTagLine.setText('')
                self.ui.tagCurQfPosBtn.setText('Tag It')


    def connectFreqCursor(self):

        try:
            self.freqCurs[self.oldFreqCurs].moved.disconnect()
        except:
            pass
        self.freqCurs[self.oldFreqCurs].trafficLight(False,False)
        self.freqCurs[self.ui.freqCursListCmbBox.currentIndex()].moved.connect(self.trackCursor)
        self.freqCurs[self.ui.freqCursListCmbBox.currentIndex()].trafficLight(True,False)
        pos = self.freqCurs[self.ui.freqCursListCmbBox.currentIndex()].pos()
        self.ui.freqCursXNum.setValue(pos[0])
        self.ui.freqCursYNumDbl.setValue(pos[1])
        self.oldFreqCurs = self.ui.freqCursListCmbBox.currentIndex()


    def connectQfCursor(self):

        try:
            self.qfCurs[self.oldQfCurs].moved.disconnect()
        except:
            pass
        self.qfCurs[self.oldQfCurs].trafficLight(False,False)
        self.qfCurs[self.ui.qfCursListCmbBox.currentIndex()].moved.connect(self.trackCursor)
        self.qfCurs[self.ui.qfCursListCmbBox.currentIndex()].trafficLight(True,False)
        pos = self.qfCurs[self.ui.qfCursListCmbBox.currentIndex()].pos()
        self.ui.qfCursXNum.setValue(pos[0])
        self.ui.qfCursYNumDbl.setValue(pos[1])
        self.oldQfCurs = self.ui.qfCursListCmbBox.currentIndex()


    def disconnectFreqCursor(self):

        try:
            self.freqCurs[self.ui.freqCursListCmbBox.currentIndex()].moved.disconnect()
        except:
            pass


    def disconnectQfCursor(self):

        try:
            self.qfCurs[self.ui.qfCursListCmbBox.currentIndex()].moved.disconnect()
        except:
            pass


    def applyTag(self,xPos,tagText):

        posYf = self.freqCurve.yData[list(self.freqCurve.xData).index(xPos)]
        posYqf = self.qfCurve.yData[list(self.qfCurve.xData).index(xPos)]
        x = list(self.tagFreq.xData)
        y = list(self.tagFreq.yData)
        x.append(xPos)
        y.append(posYf)
        self.tagFreq.setData(x,y)
        self.ui.freqPlot.update()
        x = list(self.tagQf.xData)
        y = list(self.tagQf.yData)
        x.append(xPos)
        y.append(posYqf)
        self.tagQf.setData(x,y)
        self.ui.qPlot.update()
        self.tagLegend.append(tagText)
        self.tags[int(xPos-1)] = len(self.tagLegend)

        currDs = bool(self.dataSaved)
        self.dataSaved = False

        if self.dataSaved != currDs: self.setLegend()

        logString = 'Added a tag at point {0} with text: {1}'.format(xPos,tagText)
        self.simpleLogger(logString)


    def removeTag(self, xPos):

        ind = int(xPos-1)
        tagNum = self.tags[ind]
        taggedAfter = where(array(self.tags)>tagNum)[0]
        self.tags[ind] = 0.0
        del self.tagLegend[int(tagNum-1)]
        for t in taggedAfter:
            self.tags[t]-=1
        x = list(self.tagFreq.xData)
        y = list(self.tagFreq.yData)
        ind2 = x.index(xPos)
        del x[ind2]
        del y[ind2]
        self.tagFreq.setData(x,y)
        x = list(self.tagQf.xData)
        y = list(self.tagQf.yData)
        del x[ind2]
        del y[ind2]
        self.tagQf.setData(x,y)

        currDs = bool(self.dataSaved)
        self.dataSaved = False

        if self.dataSaved != currDs: self.setLegend()

        logString = 'Removed tag at point {0}'.format(xPos)
        self.simpleLogger(logString)


    def tagIt(self):

        culprit = self.sender()
        curs = self.freqCurs[self.ui.freqCursListCmbBox.currentIndex()] if culprit is self.ui.tagCurFreqPosBtn else self.qfCurs[self.ui.qfCursListCmbBox.currentIndex()]
        pos = curs.pos()
        if culprit.text() == 'Tag It':
            newTag,ok = QInputDialog.getText(self,'Enter a tag','Enter your tag here:',QLineEdit.Normal)
            if not ok:
                return
            reply = QMessageBox.question(self, 'Message',
                                         "Do you really want to tag this point?",
                                         QMessageBox.Yes, QMessageBox.No)
            if reply == QMessageBox.No:
                return
            self.applyTag(pos[0],newTag)
        else:
            self.removeTag(pos[0])


    def simpleLogger(self,entry):
        completeEntry = strftime('%Y/%m/%d') + '-' + strftime('%H:%M:%S') + ' -- ' + entry + '\n'
        self.ui.logText.insertPlainText(completeEntry)


    def simpleQuestion(self,message):

        reply = QMessageBox.question(self, 'Message',
                                     message, QMessageBox.Yes, QMessageBox.No)
        return reply


    def whatsThat(self):

        warning = QMessageBox.about(self,'Flowing liquid experiment','When the liquid is flowing, major problems are: viscous damping of oscillations,'
                        'medium temperature fluctuations and non-specific adsorbtions.'
                        'So, an empirical equation has been proposed:\nΔf = aρ^(1/2)+ bη^(1/2)- c\n'
                        'where:\na,b and c are constants; ρ is the density and η is the viscosity of the solution.\n'
                        'The constants have to be provided by the user')


    def aboutMe(self):

        warning = QMessageBox.about(self,'About',ABOUT)


    def actionConnections(self):

        self.ui.action_Load_Parameters.triggered.connect(self.loadParams)
        self.ui.action_Save_Parameters.triggered.connect(self.saveParams)
        self.ui.action_Load.triggered.connect(self.loadData)
        self.ui.action_Save.triggered.connect(lambda: self.saveData(None))
        self.ui.action_Exit.triggered.connect(self.close)
        self.ui.action_Reconnect.triggered.connect(self.reconnect)
        self.ui.action_About.triggered.connect(self.aboutMe)


    def booleanConnections(self):

        self.ui.autoSaveEnabCkBox.stateChanged.connect(self.ui.autoSaveConfCkBox.setEnabled)
        self.ui.autoSaveEnabCkBox.stateChanged.connect(self.checkAutoSaveEnv)

        self.ui.rawFreqRadio.toggled.connect(self.rawOrAligned)
        self.ui.varFreqRadio.toggled.connect(self.rawOrAligned)
        self.ui.rawQfRadio.toggled.connect(self.rawOrAligned)
        self.ui.varQfRadio.toggled.connect(self.rawOrAligned)

        self.sigChangerConnections()


    def sigChangerConnections(self):

        self.ui.freqRadio.toggled.connect(self.changeSig1)
        self.ui.massRadio.toggled.connect(self.changeSig1)
        self.ui.viscRadio.toggled.connect(self.changeSig1)
        self.ui.flowCkBox.stateChanged.connect(self.changeSig1)


    def buttonConnections(self):

        self.ui.playBtn.clicked.connect(self.startExperiment)
        self.ui.stopBtn.clicked.connect(self.stopExperiment)
        self.ui.addFreqCurBtn.clicked.connect(self.addCursor)
        self.ui.addQfCurBtn.clicked.connect(self.addCursor)
        self.ui.removeFreqCursBtn.clicked.connect(self.removeCursor)
        self.ui.removeQfCursBtn.clicked.connect(self.removeCursor)
        self.ui.tagCurFreqPosBtn.clicked.connect(self.tagIt)
        self.ui.tagCurQfPosBtn.clicked.connect(self.tagIt)
        self.ui.whatsThatBtn.clicked.connect(self.whatsThat)
        self.ui.dirBrowseBtn.clicked.connect(self.browseDataDir)


    def genericConnections(self):

        self.ui.freqCursListCmbBox.currentIndexChanged.connect(self.connectFreqCursor)
        self.ui.qfCursListCmbBox.currentIndexChanged.connect(self.connectQfCursor)
        self.ui.timeResNumDbl.valueChanged.connect(self.changeChunkLen)
        self.ui.expBaseNameLine.textChanged.connect(self.preCheckAutoSaveEnv)
        self.ui.expDirLine.textChanged.connect(self.preCheckAutoSaveEnv)
        self.ui.autoSaveIndNum.valueChanged.connect(self.preCheckAutoSaveEnv)
        self.ui.quartzBasicFreqNumDbl.valueChanged.connect(self.setNewFreq)

        self.sigCheckerConnections()


    def sigCheckerConnections(self):

        self.ui.mediumDensNumDbl.valueChanged.connect(self.liquidCheck)
        self.ui.aParNumDbl.valueChanged.connect(self.liquidCheck)
        self.ui.bParNumDbl.valueChanged.connect(self.liquidCheck)
        self.ui.cParNumDbl.valueChanged.connect(self.liquidCheck)
        self.ui.quartzBasicFreqNumDbl.valueChanged.connect(self.liquidCheck)
        self.ui.quartzViscNumDbl.valueChanged.connect(self.liquidCheck)
        self.ui.quartzDensNumDbl.valueChanged.connect(self.liquidCheck)

        self.ui.quartzViscNumDbl.valueChanged.connect(self.gasCheck)
        self.ui.quartzDensNumDbl.valueChanged.connect(self.gasCheck)
        self.ui.overToneNumDbl.valueChanged.connect(self.gasCheck)
        self.ui.quartzBasicFreqNumDbl.valueChanged.connect(self.gasCheck)

        self.ui.quartzBasicFreqNumDbl.valueChanged.connect(self.normCheck)


    def sigChangerDisconnect(self):

        self.ui.freqRadio.toggled.disconnect()
        self.ui.massRadio.toggled.disconnect()
        self.ui.viscRadio.toggled.disconnect()
        self.ui.flowCkBox.stateChanged.disconnect()


    def sigCheckerDisconnect(self):

        self.ui.mediumDensNumDbl.valueChanged.disconnect()
        self.ui.aParNumDbl.valueChanged.disconnect()
        self.ui.bParNumDbl.valueChanged.disconnect()
        self.ui.cParNumDbl.valueChanged.disconnect()
        self.ui.quartzBasicFreqNumDbl.valueChanged.disconnect()
        self.ui.quartzViscNumDbl.valueChanged.disconnect()
        self.ui.quartzDensNumDbl.valueChanged.disconnect()
        self.ui.overToneNumDbl.valueChanged.disconnect()


    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Message',
            "Do you really want to close EPiQ?", QMessageBox.Yes, QMessageBox.No)

        if reply == QMessageBox.Yes:
            if not self.simulation:
                self.qcmComm.stopDev()
            event.accept()
        else:
            event.ignore()



class hwReadyThread(QThread):

    timeOutSignal = pyqtSignal()

    def __init__(self,parent,delay=2.0,trials=3):

        super(hwReadyThread,self).__init__(parent)
        self.parent = parent
        self.go = True
        self.maxDelay = delay*1000
        self.maxTrials = trials
        self.currentTrial = 0


    def run(self):
        startTimeDate = datetime.now().time()
        startTime = startTimeDate.hour*3600000+startTimeDate.minute*60000+startTimeDate.second*1000+startTimeDate.microsecond/1000

        while self.go:
            if self.parent.qcmData.isRunning():
                self.go = False
                continue
            currTimeDate = datetime.now().time()
            currTime = currTimeDate.hour*3600000+currTimeDate.minute*60000+currTimeDate.second*1000+currTimeDate.microsecond/1000
            if currTime-startTime>=self.maxDelay:
                self.currentTrial += 1
                if self.currentTrial >= self.maxTrials:
                    self.timeOutSignal.emit()
                    self.go = False
                    continue
                else:
                    self.parent.setEpz()
            sleep(0.2)



class SimulHW(QThread):

    chunkReceived = pyqtSignal(list,name='chunkReceived')

    def __init__(self,parent):

        super(SimulHW,self).__init__(parent)
        self.chunk = 1000
        self.sleepTime = 0.5
        self.goAhead = True


    def run(self):

        while self.goAhead:
            x = list(rnd(self.chunk)+rnd(self.chunk))
            y = list(rnd(self.chunk)+pi*rnd(self.chunk))
            z = list(3*rnd(self.chunk)+rnd(self.chunk)/2)
            data = [x,y,z]
            self.chunkReceived.emit(data)
            sleep(self.sleepTime)
